# EP1 Cálculo Numérico - Classificador de Dígitos

* Feito em python 3.5.3, ambiente MACOS 10.13.6
* Para rodar, faça: `python main.py` (precisa de Python versão 3.5 ou maior)
* Escolha a parte do exercício que deseja rodar a partir do terminal.
* Bibliotecas usadas:
    * math (sqrt)
    * numpy (matmul, sqrt, zeros, ones, transpose, subtract, array, inf)
    * random (uniform)
    * copy (deepcopy)
    * time (time)
